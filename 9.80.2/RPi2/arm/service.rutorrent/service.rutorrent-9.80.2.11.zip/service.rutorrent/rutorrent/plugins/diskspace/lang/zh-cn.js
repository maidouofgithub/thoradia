﻿/*
 * PLUGIN DISKSPACE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "警告! 存储空间已满. rTorrent 可能不会正常运行, 并且在你释放一些空间之前, 将不会下载数据.";

thePlugins.get("diskspace").langLoaded();
