﻿/*
 * PLUGIN DATA
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.getData		= "Отримати файл";
 theUILang.cantAccessData	= "Користувач веб-сервера не має доступу до даних цього торента.";

thePlugins.get("data").langLoaded();