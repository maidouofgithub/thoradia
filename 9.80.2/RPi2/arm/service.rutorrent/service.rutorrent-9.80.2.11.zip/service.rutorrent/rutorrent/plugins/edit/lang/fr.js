﻿/*
 * PLUGIN EDIT
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.EditTrackers			= "Éditer le(s) torrent(s)...";
 theUILang.EditTorrentProperties	= "Propriétés du ou des torrents";
 theUILang.errorAddTorrent		= "Erreur lors de l'ajout du .torrent";
 theUILang.errorWriteTorrent		= "Erreur lors de l'écriture du .torrent";
 theUILang.errorReadTorrent		= "Erreur lors de la lecture du .torrent";
 theUILang.cantFindTorrent		= "Le fichier source pour ce torrent n'a pas été trouvé."

thePlugins.get("edit").langLoaded();
