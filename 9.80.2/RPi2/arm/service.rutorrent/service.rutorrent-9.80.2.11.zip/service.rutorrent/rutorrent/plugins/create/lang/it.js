﻿/*
 * PLUGIN CREATE
 *
 * Italian language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "Crea Torrent...";
 theUILang.CreateNewTorrent		= "Crea nuovo torrent";
 theUILang.SelectSource			= "Seleziona la sorgente";
 theUILang.TorrentProperties		= "Proprità torrent";
 theUILang.PieceSize			= "Dimensioni parte";
 theUILang.Other			= "Altro";
 theUILang.StartSeeding			= "Comincia il seeding";
 theUILang.PrivateTorrent		= "Torrent privato";
 theUILang.torrentCreate		= "Crea...";
 theUILang.BadTorrentData		= "Devi completare tutti i campi!";
 theUILang.createExternalNotFound	= "Create plugin: Il Plugin non funziona. L'utente non può accedere al programma esterno";
 theUILang.incorrectDirectory		= "Direcory errata";
 theUILang.cantExecExternal		= "Non posso eseguire il programma esterno";
 theUILang.createConsole		= "Console";
 theUILang.createErrors			= "Errori";
 theUILang.torrentSave			= "Salva";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Il processo è stato arrestato.";
 theUILang.recentTrackers		= "Trackers recenti";
 theUILang.source			= "Source";

thePlugins.get("create").langLoaded();