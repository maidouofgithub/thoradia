﻿/*
 * PLUGIN COOKIES
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.cookiesDesc		= "Cookies (Formato: host|cookie1;cookie2...)";
 theUILang.cookiesName		= "Cookies";

thePlugins.get("cookies").langLoaded();