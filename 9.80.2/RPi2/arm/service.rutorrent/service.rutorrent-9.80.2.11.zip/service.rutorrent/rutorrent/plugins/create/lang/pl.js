﻿/*
 * PLUGIN CREATE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.mnu_create			= "Utwórz...";
 theUILang.CreateNewTorrent		= "Utwórz nowy plik torrent";
 theUILang.SelectSource			= "Wybierz źródło";
 theUILang.TorrentProperties		= "Właściwości torrenta";
 theUILang.PieceSize			= "Rozmiar części";
 theUILang.Other			= "Inne";
 theUILang.StartSeeding			= "Udostępnij";
 theUILang.PrivateTorrent		= "Prywatny torrent";
 theUILang.torrentCreate		= "Utwórz...";
 theUILang.BadTorrentData		= "Musisz wypełnić wszystkie wymagane pola!";
 theUILang.createExternalNotFound	= "Wtyczka create: Wtyczka nie będzie działać. Użytkownik serwera www nie ma dostępu do zewnętrznego programu";
 theUILang.incorrectDirectory		= "Niepoprawny folder";
 theUILang.cantExecExternal		= "Nie można uruchomić zewnętrznego programu";
 theUILang.createConsole		= "Konsola";
 theUILang.createErrors			= "Błędy";
 theUILang.torrentSave			= "Zapisz";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Proces został zatrzymany.";
 theUILang.recentTrackers		= "Ostatnie trackery";
 theUILang.source			= "Źródło";

thePlugins.get("create").langLoaded();