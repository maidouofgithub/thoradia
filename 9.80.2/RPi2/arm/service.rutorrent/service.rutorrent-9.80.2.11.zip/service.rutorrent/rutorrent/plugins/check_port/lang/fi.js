﻿/*
 * PLUGIN CHECK_PORT
 *
 * Finnish language file.
 *
 * Author: 
 */

 theUILang.checkPort		= "Check Port Status";
 theUILang.portStatus		= [
 				  "Port status is unknown",
 				  "Port is closed",
 				  "Port is open"
 				  ];

thePlugins.get("check_port").langLoaded();