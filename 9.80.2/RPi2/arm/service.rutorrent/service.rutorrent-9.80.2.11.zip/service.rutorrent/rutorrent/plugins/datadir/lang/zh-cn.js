﻿/*
 * PLUGIN DATADIR
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "保存到";
 theUILang.DataDirMove		= "移动数据文件";
 theUILang.datadirDlgCaption	= "Torrent 数据目录";
 theUILang.datadirDirNotFound	= "DataDir 插件: 无效的目录";
 theUILang.datadirSetDirFail	= "DataDir 插件: 操作失败";

thePlugins.get("datadir").langLoaded();
