﻿/*
 * PLUGIN EXTRATIO
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.ratioRulesManager	= "规则管理器";
 theUILang.mnu_ratiorule	= "分享率规则";
 theUILang.ratAddRule		= "添加";
 theUILang.ratDelRule		= "删除";
 theUILang.ratUpRule		= "上升";
 theUILang.ratDownRule		= "下降";
 theUILang.ratioIfLegend	= "如果";
 theUILang.ratLabelContain	= "Torrent 标签中含有";
 theUILang.ratTrackerContain	= "Torrent 的某个 tracker 地址含有";
 theUILang.ratTrackerPublic	= "所有 torrent 的 trackers 是公开的";
 theUILang.ratTrackerPrivate	= "Torrent的某个 trackers 是私有的";
 theUILang.ratioThenLegend	= "然后";
 theUILang.setRatioTo		= "把分享率设为";
 theUILang.setChannelTo		= "把限制设为";
 theUILang.ratioNewRule		= "新规则";

thePlugins.get("extratio").langLoaded();
