﻿/*
 * PLUGIN CREATE
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.mnu_create			= "Maak torrent...";
 theUILang.CreateNewTorrent		= "Maak Torrent";
 theUILang.SelectSource			= "Selecteer Folder/Bestand";
 theUILang.TorrentProperties		= "Torrent Eigenschappen";
 theUILang.PieceSize			= "Stuk Grote";
 theUILang.Other			= "Diverse";
 theUILang.StartSeeding			= "Start uploaden";
 theUILang.PrivateTorrent		= "Prive torrent";
 theUILang.torrentCreate		= "Maak...";
 theUILang.BadTorrentData		= "U moet alle verplichte velden invullen!";
 theUILang.createExternalNotFound	= "Maak Torrent plugin: Plugin zal niet werken. Web-server heeft geen toegang tot extern programma";
 theUILang.incorrectDirectory		= "Ongeldige map";
 theUILang.cantExecExternal		= "Kan extern programma niet uitvoeren";
 theUILang.createConsole		= "Console";
 theUILang.createErrors			= "Fouten";
 theUILang.torrentSave			= "Opslaan";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "proces is gestopt.";
 theUILang.recentTrackers		= "Recent trackers";
 theUILang.source			= "Source";

thePlugins.get("create").langLoaded();