﻿/*
 * PLUGIN CREATE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "Новый торрент...";
 theUILang.CreateNewTorrent		= "Новый торрент";
 theUILang.SelectSource			= "Выбор источника";
 theUILang.TorrentProperties		= "Настройка торрента";
 theUILang.PieceSize			= "Размер части";
 theUILang.Other			= "Другое";
 theUILang.StartSeeding			= "Начать раздачу";
 theUILang.PrivateTorrent		= "Частный торрент";
 theUILang.torrentCreate		= "Создать...";
 theUILang.BadTorrentData		= "Вы должны заполнить обязательные поля!";
 theUILang.createExternalNotFound	= "Плагин Create: веб-серверу не доступна внешняя программа";
 theUILang.incorrectDirectory		= "Неверная директория";
 theUILang.cantExecExternal		= "Ошибка выполнения внешней программы";
 theUILang.createConsole		= "Консоль";
 theUILang.createErrors			= "Ошибки";
 theUILang.torrentSave			= "Сохранить";
 theUILang.torrentKill			= "Остановить";
 theUILang.torrentKilled		= "Процесс остановлен.";
 theUILang.recentTrackers		= "Недавние трекеры";
 theUILang.source			= "Источник";

thePlugins.get("create").langLoaded();