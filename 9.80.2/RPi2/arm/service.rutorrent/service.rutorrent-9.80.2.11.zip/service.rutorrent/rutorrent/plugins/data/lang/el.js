﻿/*
 * PLUGIN DATA
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.getData		= "Λήψη αρχείου";
 theUILang.cantAccessData	= "Ο χρήστης του διακομιστή Web δεν έχει πρόσβαση στα δεδομένα αυτού του torrent.";

thePlugins.get("data").langLoaded();